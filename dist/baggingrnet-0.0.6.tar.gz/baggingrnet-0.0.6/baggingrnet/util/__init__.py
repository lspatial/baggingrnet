# -*- coding: utf-8 -*-
"""
Package for the metrics functions such as rsquared and rmse

Author: Lianfa Li
Date: 2019-08-01

"""
from baggingrnet.util.pmetrics import *